require('./config');
require('./Yakuza');
const fs = require('fs')
const chalk = require('chalk')

global.menu = `
╔──☉︎ *List Menu*
│✎.menuall
│✎.menuowner
│✎.menugroup
│✎.menupanel
│✎.menuai
│✎.menudownload
│✎.menuother
│✎.menuquotes
│✎.menupush
│✎.menuislam
│✎.menumaker
│✎.menuberita
│✎.menulinode
│✎.menumenfess
│✎.menugame
│✎.menustore
│✎.menusearch
│✎.menubug
│✎.menustalk
╚─────────────☉`

global.allmenu = `
╔──☉ *O W N E R* 
│✎.listowner
│✎.addowner
│✎.delowner
│✎.listgc
│✎.onlygc
│✎.listprem
│✎.delprem
│✎.public
│✎.self
│✎.setppbot
│✎.delppbot
│✎.tojs
│✎.join
│✎.rvo
│✎.autoread
│✎.autotyping
│✎.autosholat
│✎.clearchat
│✎.reactch
│✎.addplugin
│✎.delplugin
│✎.listplugin
│✎.getplugin
│✎.on
│✎.off
│✎.upswtag
│✎.nglspam
│✎.setbotname
│✎.setbotbio
│✎.autobio
│✎.addcase
│✎.delcase
│✎.listcase
│✎.getcase
│✎.creategc
│✎.restart
╰─────────────☉
╭──☉ *G R O U P* 
│✎.kick
│✎.tagall
│✎.hidetag
│✎.totag
│✎.setppgc
│✎.delppgc
│✎.promote
│✎.demote
│✎.open
│✎.close
│✎.opentime
│✎.closetime
│✎.linkgc
│✎.resetlinkgc
│✎.antilinkgc
│✎.antilinkch
│✎.antiwame
│✎.antilinkig
│✎.antilinkall
│✎.delete
╰─────────────☉
╭──☉ *P A N E L* 
│✎.1gb
│✎.2gb
│✎.3gb
│✎.4gb
│✎.5gb
│✎.6gb
│✎.7gb
│✎.8gb
│✎.9gb
│✎.10gb
│✎.unli
│✎.listpanel
│✎.delpanel
│✎.cadmin
│✎.deladmin
│✎.listadmin
╰─────────────☉
╭──☉ *A I - G E M I N I* 
│✎.autoai
│✎.ai
│✎.openai
│✎.gpt
│✎.luminai
│✎.gemini
│✎.google
│✎.putihkan
│✎.hitamkan
│✎.pretty
│✎.ugly
│✎.sedih
│✎.senyum
│✎.night
│✎.ocr
│✎.bingimg
│✎.toanime
│✎.toreal
│✎.faceblur
│✎.botakin
│✎.removal
╰─────────────☉
╭──☉ *D O W N L O A D* 
│✎.TikTok
│✎.Instagram
│✎.facebook
│✎.Capcut
│✎.Snackvideo
│✎.Mediafire
│✎.Gdrive
│✎.Gitclone
│✎.ytmp4
│✎.ytmp3
│✎.play
│✎.yts
╰─────────────☉
╭──☉ *C O N V E R T* 
│✎.bass
│✎.blown
│✎.deep
│✎.earrape
│✎.fast
│✎.fat
│✎.night
│✎.ocrcore
│✎.reverse
│✎.robot
│✎.slow
│✎.smooth
│✎.tupai
╰─────────────☉
╭──☉ *O T H E R* 
│✎.brat
│✎.bratvid
│✎.sticker
│✎.smeme
│✎.swm
│✎.tourl
│✎.tourl2
│✎.hd
│✎.tohd
│✎.hdvid
│✎.superhd
│✎.qc
│✎.tovn
│✎.toaudio
│✎.toimg
│✎.getpp
│✎.readmore
│✎.iqc
│✎.tts
│✎.owner
│✎.enc
│✎.ssweb
│✎.pastebin
│✎.getpp
╰─────────────☉
╭──☉ *Q U O T E S* 
│✎.faktaunik
│✎.katailham
│✎.katasenja
│✎.motivasi
│✎.pantun
│✎.puisi
│✎.quotes
│✎.quotesanime
│✎.quotesbucin
│✎.quotesdilan
│✎.quotesislamic
╰─────────────☉
╭──☉ *P U S H* 
│✎.pushkontak
│✎.pushkontak2
│✎.savekontak
│✎.savekontak2
╰─────────────☉
╭──☉ *I S L A M* 
│✎.jadwalsholat
│✎.alquran
│✎.asmaulhusna
│✎.niatsholat
│✎.surah
│✎.berdoa
│✎.ayatkursi
│✎.gislam
│✎.kataislam
│✎.pantunislam
╰─────────────☉
╭──☉ *M A K E R* 
│✎.txt2img
│✎.txt2imgv2
│✎.txt2imgv3
│✎.txt2imgv4
│✎.txt2imgv5
│✎.txt2imgv6
│✎.bratgenerator
│✎.pak-ustad
│✎.pak-ustad2
│✎.ngl
╰─────────────☉
╭──☉ *B E R I T A* 
│✎.fajar
│✎.cnn
│✎.layarkaca
│✎.cnbc
│✎.tribun
│✎.indozone
│✎.kompas
│✎.detiknews
│✎.dailynews
│✎.inews
│✎.okezone
│✎.sindo
│✎.tempo
│✎.antara
│✎.kontan
│✎.merdeka
│✎.jalantikus
╰─────────────☉
╭──☉ *L I N O D E* 
│✎.linode2gb
│✎.linode4gb
│✎.linode8gb
│✎.linode16gb
│✎.listlinode
│✎.onlinode
│✎.offlinode
│✎.rebootlinode
│✎.rebuildlinode
│✎.delinode
│✎.saldolinode
│✎.sisalinode
│✎.cekvpslinode
╰─────────────☉
╭──☉ *M E N F E S S* 
│✎.anonymous
│✎.start
│✎.mulai
│✎.leave
│✎.keluar
│✎.next
│✎.lanjut
│✎.confess
│✎.menfess
╰─────────────☉
╭──☉ *G A M E* 
│✎.tebakkata
│✎.asahotak
│✎.susunkata
│✎.tebakgambar
│✎.tebakbendera
│✎.tebakkimia
│✎.family100
╰─────────────☉
╭──☉ *S T O R E* 
│✎.cekidch
│✎.upch
│✎.sendgc
│✎.proses
│✎.done
│✎.list
│✎.addlist
│✎.dellist
│✎.updatelist
│✎.payment
╰─────────────☉
╭──☉ *S E A R C H* 
│✎.playstore
│✎.playstation
│✎.google
│✎.yts
│✎.soundcloud
│✎.play
│✎.pin
╰─────────────☉
╭──☉ *B U G* 
│✎.fclose
│✎.forceclose
│✎.fc-invis
│✎.delaymaker
│✎.delayinvis
│✎.crash
│✎.delayip
╰─────────────☉
╭──☉ *S T A L K E R* 
│✎.stalkff
│✎.stalkml
│✎.stalkgmail
│✎.stalkgc
╚─────────────☉
`

global.menuowner = `
╔──☉ *O W N E R* 
│✎.listowner
│✎.addowner
│✎.delowner
│✎.listgc
│✎.onlygc
│✎.listprem
│✎.delprem
│✎.public
│✎.self
│✎.setppbot
│✎.delppbot
│✎.tojs
│✎.join
│✎.rvo
│✎.autoread
│✎.autotyping
│✎.autosholat
│✎.clearchat
│✎.reactch
│✎.addplugin
│✎.delplugin
│✎.listplugin
│✎.getplugin
│✎.on
│✎.off
│✎.upswtag
│✎.nglspam
│✎.setbotname
│✎.setbotbio
│✎.autobio
│✎.addcase
│✎.delcase
│✎.listcase
│✎.getcase
│✎.creategc
│✎.restart
╚─────────────☉`

global.menugroup = `
╔──☉ *G R O U P* 
│✎.addlist
│✎.dellist
│✎.updatelist
│✎.list
│✎.kick
│✎.tagall
│✎.hidetag
│✎.totag
│✎.setppgc
│✎.delppgc
│✎.promote
│✎.demote
│✎.open
│✎.close
│✎.opentime
│✎.closetime
│✎.linkgc
│✎.resetlinkgc
│✎.antilinkgc
│✎.antilinkch
│✎.antiwame
│✎.antilinkig
│✎.antilinkall
│✎.delete
╚─────────────☉`

global.menupanel = `
╔──☉ *P A N E L* 
│✎.1gb
│✎.2gb
│✎.3gb
│✎.4gb
│✎.5gb
│✎.6gb
│✎.7gb
│✎.8gb
│✎.9gb
│✎.10gb
│✎.unli
│✎.listpanel
│✎.delpanel
│✎.cadmin
│✎.deladmin
│✎.listadmin
╚─────────────☉
`
global.menuai = `
╔──☉ *A I - G E M I N I* 
│✎.autoai
│✎.ai
│✎.openai
│✎.gpt
│✎.luminai
│✎.gemini
│✎.google
│✎.putihkan
│✎.hitamkan
│✎.pretty
│✎.ugly
│✎.sedih
│✎.senyum
│✎.night
│✎.ocr
│✎.bingimg
│✎.toanime
│✎.toreal
│✎.faceblur
│✎.botakin
│✎.removal
╚─────────────☉
`
global.menudownload = `
╔──☉ *D O W N L O A D* 
│✎.TikTok
│✎.Instagram
│✎.facebook
│✎.Capcut
│✎.Snackvideo
│✎.Mediafire
│✎.Gdrive
│✎.Gitclone
│✎.ytmp4
│✎.ytmp3
│✎.play
│✎.yts
╚─────────────☉
`
global.menuother = `
╔──☉ *O T H E R* 
│✎.brat
│✎.bratvid
│✎.sticker
│✎.smeme
│✎.swm
│✎.tourl
│✎.tourl2
│✎.hd
│✎.tohd
│✎.hdvid
│✎.superhd
│✎.qc
│✎.tovn
│✎.toaudio
│✎.toimg
│✎.getpp
│✎.readmore
│✎.iqc
│✎.tts
│✎.owner
│✎.enc
│✎.ssweb
│✎.pastebin
│✎.getpp
╚─────────────☉
`
global.menuquotes = `
╔──☉ *Q U O T E S* 
│✎.faktaunik
│✎.katailham
│✎.katasenja
│✎.motivasi
│✎.pantun
│✎.puisi
│✎.quotes
│✎.quotesanime
│✎.quotesbucin
│✎.quotesdilan
│✎.quotesislamic
╚─────────────☉
`
global.menupush = `
╔──☉ *P U S H* 
│✎.pushkontak
│✎.pushkontak2
│✎.savekontak
│✎.savekontak2
╚─────────────☉
`
global.menuislam = `
╔──☉ *I S L A M* 
│✎.jadwalsholat
│✎.alquran
│✎.asmaulhusna
│✎.niatsholat
│✎.surah
│✎.berdoa
│✎.ayatkursi
│✎.gislam
│✎.kataislam
│✎.pantunislam
╚─────────────☉
`
global.menumaker = `
╔──☉ *M A K E R* 
│✎.txt2img
│✎.txt2imgv2
│✎.txt2imgv3
│✎.txt2imgv4
│✎.txt2imgv5
│✎.txt2imgv6
│✎.bratgenerator
│✎.pak-ustad
│✎.pak-ustad2
│✎.ngl
╚─────────────☉
`
global.menuberita = `
╔──☉ *B E R I T A* 
│✎.fajar
│✎.cnn
│✎.layarkaca
│✎.cnbc
│✎.tribun
│✎.indozone
│✎.kompas
│✎.detiknews
│✎.dailynews
│✎.inews
│✎.okezone
│✎.sindo
│✎.tempo
│✎.antara
│✎.kontan
│✎.merdeka
│✎.jalantikus
╚─────────────☉
`
global.menulinode = `╔──☉ *L I N O D E* 
│✎.linode2gb
│✎.linode4gb
│✎.linode8gb
│✎.linode16gb
│✎.listlinode
│✎.onlinode
│✎.offlinode
│✎.rebootlinode
│✎.rebuildlinode
│✎.delinode
│✎.saldolinode
│✎.sisalinode
│✎.cekvpslinode
╚─────────────☉
`
global.menumenfess = `
╔──☉ *M E N F E S S* 
│✎.anonymous
│✎.start
│✎.mulai
│✎.leave
│✎.keluar
│✎.next
│✎.lanjut
│✎.confess
│✎.menfess
╚─────────────☉
`
global.menugame = `
╔──☉ *G A M E* 
│✎.tebakkata
│✎.asahotak
│✎.susunkata
│✎.tebakgambar
│✎.tebakbendera
│✎.tebakkimia
│✎.family100
╚─────────────☉
`
global.menustore = `
╔──☉ *S T O R E* 
│✎.cekidch
│✎.upch
│✎.sendgc
│✎.proses
│✎.done
│✎.list
│✎.addlist
│✎.dellist
│✎.updatelist
│✎.payment
╚─────────────☉
`
global.menuse = `
╔──☉ *S E A R C H* 
│✎.playstore
│✎.playstation
│✎.google
│✎.yts
│✎.soundcloud
│✎.play
│✎.pin
╚─────────────☉
`
global.menubug = `
╔──☉ *B U G* 
│✎.fclose
│✎.forceclose
│✎.fc-invis
│✎.delaymaker
│✎.delayinvis
│✎.crash
│✎.delayip
╚─────────────☉`
global.stalkmenu = `
╔──☉ *S T A L K E R* 
│✎.stalkff
│✎.stalkml
│✎.stalkgmail
│✎.stalkgc
╚─────────────☉`
//============{ Import } =============