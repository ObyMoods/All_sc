module.exports = {
  BOT_TOKEN: "",//bot tokenlu
  OWNER_ID: [""],//id lu
  API_HASH: "",
  API_ID: 0,//ganti 0 dan langsung isi angka nya saja ex: 12323232
  //Baca Readme.txt agar kalian faham cara menggunakan ban CH ( Login Dengan Akun Telegram Premium Lebih Work Dan Cepat Terban ) terima kasih
  // Thanks To Ota And Dimz
};
//BY OTAX